/*----------------------------------------------------------
 *				HTBLA-Leonding / Class
 * ---------------------------------------------------------
 * Exercise Number: 0
 * Title:			deletable_primes.c
 * Author:			Patrick Spisak
 * Due Date:	 Februar 1.2018
 * ----------------------------------------------------------
 * Description:
 * Implementation of deletable_primes.h.
 * ----------------------------------------------------------
 */
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "deletable_primes.h"
	
	int theLength (int theInt)
	{
		int counter = 0;
		while(theInt != 0)
		{
			theInt /= (int)10;
			counter ++;
		}

		return counter;
	}	

	bool isPrime(unsigned long copy)
	{
		if(copy % 2 == 0){return false;}		

		if(copy == 2)
		{
			return true;
		}

		for(int i=3 ;i <= (copy/2);i++)
		{
			if(copy % i == 0)
			{
				return false;
			}
		}

		
		return true;	
	}	

	unsigned long remove_digit(int index, unsigned long n)
	{
		unsigned long output = ( (int)(n / (int)(pow(10,index + (int)1)) ) *(int)pow(10,(index)) )  +  (int)( n -   (int)( (int)( n / (int)(pow(10,index)) )  * (int)pow(10,index) )  );
		

		return output; 
	}

	int get_ways(unsigned long p)
	{
	
		if(p < 10 && p!= 1 && p!= 4 && p!= 6 && p != 8 && p!= 9)
		{
			return 1;
		}
		
		else if(p < 10)
		{
			return 0;
		}
		
		int ways = 0;
		unsigned long copy = p;
		int count = 0;
		int length = theLength(copy);
		while(count < length)
		{
			copy = remove_digit(count,copy);
			if(isPrime(copy))
			{
				int num = get_ways(copy);
				ways += num;	
			}
			count++;
		}

		return ways;
	}

