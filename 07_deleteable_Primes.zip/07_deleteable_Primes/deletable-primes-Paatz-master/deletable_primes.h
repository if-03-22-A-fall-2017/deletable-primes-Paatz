/*----------------------------------------------------------
 *				HTBLA-Leonding / Klasse: 2AHIF
 * ---------------------------------------------------------
 * Exercise Number: 0
 * Title:			deletable_primes.h
 * Author:			Patrick Spisak
 * Due Date:		Februar 1, 2018
 * ----------------------------------------------------------
 * Description:
 * CatCoder Deletable Primes.
 * ----------------------------------------------------------
 */
#ifndef ___DELETABLE_PRIMES
#define ___DELETABLE_PRIMES

	unsigned long remove_digit(int index, unsigned long n);

	int get_ways(unsigned long p);

#endif
